package jbr.springmvc.service;

import java.util.List;

import jbr.springmvc.model.Product;

public interface ProductService {

  void create(Product product);
  
public void saveOrUpdate(Product product);
  
  //public void delete(String id);
   
  public Product get(String id);
   
  public List<Product> list();

  //Product selectProduct(Product product);

  //Product selectProduct(Product product);
}
