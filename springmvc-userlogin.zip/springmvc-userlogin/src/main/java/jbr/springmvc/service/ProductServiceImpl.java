package jbr.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import jbr.springmvc.dao.ProductDao;

import jbr.springmvc.model.Product;

public class ProductServiceImpl implements ProductService {

  @Autowired
  public ProductDao productDao;

  public void create(Product product) {
    productDao.create(product);
  }

  @Override
  public void saveOrUpdate(Product product) {
    
    
    // TODO Auto-generated method stub
    
  }

  @Override
  public Product get(String id) {
    productDao.get(id);
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public List<Product> list() {
    productDao.list();
    
    // TODO Auto-generated method stub
    return null;
  }

  /*public Product selectProduct(Product product) {
    return productDao.selectProduct(product);
  }*/

}
