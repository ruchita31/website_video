package jbr.springmvc.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import jbr.springmvc.dao.ProductDao;
import jbr.springmvc.model.Product;
import jbr.springmvc.service.ProductService;

@Controller
public class ProductController {
  @Autowired
  public ProductDao productDao;
  
  @RequestMapping(value="/home", method = RequestMethod.GET)
  public ModelAndView listContact(ModelAndView model) throws IOException{
      List<Product> listProduct = productDao.list();
      model.addObject("listProduct", listProduct);
      model.setViewName("home");
   
      return model;
  }

  @RequestMapping(value = "/create", method = RequestMethod.GET)
  public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) {
    ModelAndView mav = new ModelAndView("create");
    mav.addObject("product", new Product());

    return mav;
  }
  
  @RequestMapping(value = "/deleteProduct", method = RequestMethod.GET)
  public ModelAndView deleteProduct(HttpServletRequest request) {
      String productId = (request.getParameter("id"));
      productDao.delete(productId);
      ModelAndView model=new ModelAndView();
      List<Product> listProduct = productDao.list();
      model.addObject("listProduct", listProduct);
      model.setViewName("home");
   
      return model;
      //return new ModelAndView("home");
  }

  @RequestMapping(value = "/creationProcess", method = RequestMethod.POST)
  public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response,
      @ModelAttribute("product") Product product) {

    productDao.create(product);
    ModelAndView model=new ModelAndView();
    List<Product> listProduct = productDao.list();
    model.addObject("listProduct", listProduct);
    model.setViewName("home");
 
    return model;
    

    //return new ModelAndView("home");
  }
  
  
  
  @RequestMapping(value = "/viewProduct", method = RequestMethod.GET)
  public ModelAndView viewProduct(HttpServletRequest request, HttpServletResponse respose,
      @ModelAttribute("product") Product product) {
      //String productId = (request.getParameter("id"));
      //productDao.get(productId);
      productDao.get(product);
      ModelAndView model=new ModelAndView();
      List<Product> listProduct = productDao.list();
      model.addObject("listProduct", listProduct);
      model.setViewName("viewProduct");
   
      return model;
      //return new ModelAndView("viewProduct");
  }
  
  
}
