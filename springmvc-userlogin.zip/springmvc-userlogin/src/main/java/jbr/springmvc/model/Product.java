package jbr.springmvc.model;

public class Product {

  private String id;
  private String name;
  private String category;
  private String description;
  private float price;
  private float rating;
  private int stock;
  
  public Product()
  {
    
  }
  public Product(String id, String name, String category, String description, float price, float rating, int stock) {
    this.id = id;
    this.name = name;
    this.category = category;
    this.description = description;
    this.price=price;
    this.rating=rating;
    this.stock=stock;
}
  

  public String getId() {
    return id;
  }

  public void setId(String id) {
    System.out.println("Id: " + id);
    this.id = id;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getCategory() {
    return category;
  }

  public void setCategory(String category) {
    System.out.println("category: " + category);
    this.category = category;
  }

  public String getDescription() {
    return description;
  }

  public void setDescription(String description) {
    System.out.println("description: " + description);
    this.description = description;
  }

  public float getPrice() {
    return price;
  }

  public void setPrice(float price) {
    this.price = price;
  }

  public float getRating() {
    return rating;
  }

  public void setRating(float rating) {
    this.rating = rating;
  }

  public int getStock() {
    return stock;
  }

  public void setStock(int stock) {
    this.stock = stock;
  }
}
