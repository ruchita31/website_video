package jbr.springmvc.dao;


import java.util.List;

import jbr.springmvc.model.Product;

public interface ProductDao {

  void create(Product product);
  
  public void saveOrUpdate(Product product);
  
  public void delete(String id);
   
  public Product get(Product product);
  
  public Product get(String id);
   
  public List<Product> list();

  Product selectProduct(Product product);
}
