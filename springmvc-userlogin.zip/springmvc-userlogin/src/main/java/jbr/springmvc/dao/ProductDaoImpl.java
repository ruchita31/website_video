package jbr.springmvc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import javax.sql.DataSource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;


import jbr.springmvc.model.Product;

public class ProductDaoImpl implements ProductDao {

  @Autowired
  DataSource datasource;

  @Autowired
  JdbcTemplate jdbcTemplate;

  public void create(Product product) {

    String sql = "insert into products values(?,?,?,?,?,?,?)";

    jdbcTemplate.update(sql, new Object[] { product.getId(), product.getName(), product.getCategory(),
        product.getDescription(), product.getPrice(), product.getRating(), product.getStock() });
  }

 
  /*public Product selectProduct(Product product) {
    String sql = "select * from product where id='" + product.getId() + "'";

    List<Product> products = jdbcTemplate.query(sql, new Product<Product>());

    return products.size() > 0 ? products.get(0) : null;
      }

 

/*class ProductMapper implements RowMapper<Product> {

  public Product mapRow(ResultSet rs, int arg1) throws SQLException {
    Product product = new Product();

    product.setId(rs.getString("id"));
    product.setName(rs.getString("name"));
    product.setCategory(rs.getString("category"));
    product.setDescription(rs.getString("description"));
    product.setPrice(rs.getFloat("price"));
    product.setRating(rs.getFloat("rating"));
    product.setStock(rs.getInt("stock"));

    return product;
  }*/
  
 
  public void delete(String id) {
    String sql = "DELETE FROM products WHERE id=?";
    jdbcTemplate.update(sql, id);
  }

  @Override


  public List<Product> list() {
    String sql = "SELECT * FROM products";
    List<Product> listproduct = jdbcTemplate.query(sql, new RowMapper<Product>() {
 
        @Override
        public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
            Product product = new Product();
 
            product.setId(rs.getString("id"));
            product.setName(rs.getString("name"));
            product.setCategory(rs.getString("category"));
            product.setDescription(rs.getString("description"));
            product.setPrice(rs.getFloat("price"));
            product.setRating(rs.getFloat("rating"));
            product.setStock(rs.getInt("stock"));

            return product;
 
        }}
        );
 
    return listproduct;
  }

  public Product selectProduct(Product product) {
    String sql = "select * from product where id='" + product.getId() + "'";
    return jdbcTemplate.query(sql, new ResultSetExtractor<Product>() {
 
        @Override
        public Product extractData(ResultSet rs) throws SQLException,
                DataAccessException {
            if (rs.next()) {
              Product product = new Product();
              product.setId(rs.getString("id"));
              product.setName(rs.getString("name"));
              product.setCategory(rs.getString("category"));
              product.setDescription(rs.getString("description"));
              product.setPrice(rs.getFloat("price"));
              product.setRating(rs.getFloat("rating"));
              product.setStock(rs.getInt("stock"));
                return product;
            }
 
            return null;
        }
 
    });
  }


  @Override
  public void saveOrUpdate(Product product) {
    // TODO Auto-generated method stub
    
  }


 
  public Product get(Product product) {
    String sql = "select * from products where id='" + product.getId()+ "'";
    return jdbcTemplate.query(sql, new ResultSetExtractor<Product>() {
 
        @Override
        public Product extractData(ResultSet rs) throws SQLException,
                DataAccessException {
            if (rs.next()) {
              Product product = new Product();
              //product.setId(rs.getString("id"));
              product.setName(rs.getString("name"));
              product.setCategory(rs.getString("category"));
              product.setDescription(rs.getString("description"));
              product.setPrice(rs.getFloat("price"));
              product.setRating(rs.getFloat("rating"));
              product.setStock(rs.getInt("stock"));
                return product;
            }
 
            return null;
        }
 
    });
  }


public Product get(String id) {
  String sql = "SELECT id,name,category,price,rating,stock FROM products WHERE id='" + id +"'";
    return jdbcTemplate.query(sql, new ResultSetExtractor<Product>() {
 
      
        public Product extractData(ResultSet rs) throws SQLException,
                DataAccessException {
            if (rs.next()) {
                Product product = new Product();
                product.setId(rs.getString("id"));
                product.setName(rs.getString("name"));
                product.setCategory(rs.getString("category"));
                //product.setDescription(rs.getString(4));
                product.setPrice(rs.getFloat("price"));
                product.setRating(rs.getFloat("rating"));
                product.setStock(rs.getInt("stock"));
                return product;
            }
 
            return null;
        }
 
    });
}







}
